<?php 

include 'header.php'; 

if(isset($_GET['promoted'])){
    $promoted_id = $_GET['promoted'];
    mysqli_query($con,"UPDATE `coins` SET `ispromote`='1' , `updated_at`=NOW() WHERE id='$promoted_id' ");
}
if(isset($_GET['unpromote'])){
    $promoted_id = $_GET['unpromote'];
    mysqli_query($con,"UPDATE `coins` SET `ispromote`='0' , `updated_at`=NOW() WHERE id='$promoted_id' ");
}
if(isset($_GET['delete'])){
    $approved_id = $_GET['delete'];
    mysqli_query($con,"DELETE FROM `coins` WHERE id='$approved_id' ");
}

?>
<div class="container-fluid">
    <h3>Promote Coins</h3>

    <div class="row">
        <div class="col-12">
            <div class="card">

                <!-- /.card-header -->
                <div class="card-body">
                    <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                    <div class="d-flex  align-items-center pb-3 pl-2">
                           <p class="mb-0">Click here to add new coin</p>
                           <a href="addcoin.php" class="btn btn-primary  ml-3">Add Coins</a>
                       </div> 
                        <div class="row">
                            <div class="col-sm-12" style="overflow-x: scroll;">
                                <table id="example2" class="table table-bordered table-hover dataTable dtr-inline"
                                    role="grid" aria-describedby="example2_info">
                                    <thead>
                                        <tr role="row">
                                            <th class="sorting sorting_asc">Id</th>
                                            <th class="sorting sorting_asc">Logo</th>
                                            <th class="sorting sorting_asc">Coin name</th>
                                            <th class="sorting sorting_asc">Symbol</th>
                                            <th class="sorting sorting_asc">Description</th>
                                            <th class="sorting sorting_asc">Launce Date</th>
                                            <th class="sorting sorting_asc">Market Cap</th>
                                            <th class="sorting sorting_asc">Network Chain</th>
                                            <th class="sorting sorting_asc">Website</th>
                                            <th class="sorting sorting_asc">Telegram</th>
                                            <th class="sorting sorting_asc">Twitter</th>
                                            <th class="sorting sorting_asc">Created At</th>
                                            <th class="sorting sorting_asc">Created By</th>
                                            <th class="sorting sorting_asc">Votes</th>
                                            <th class="sorting sorting_asc">Status</th>
                                            <th class="sorting sorting_asc">Promote</th>
                                            <th class="sorting sorting_asc text-center">Update</th>
                                            <th class="sorting sorting_asc text-center">Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                <?php
                                    $sql = mysqli_query($con,"SELECT * FROM `coins` ORDER BY created_at DESC");
                                    if(mysqli_num_rows($sql) > 0){
                                        foreach($sql as $result){
                                            $ispromote = '<span class="text-danger">Not Promoted</span>';
                                            if($result['ispromote'] == '1'){
                                                $ispromote = '<span class="text-success"> Promoted</span>';
                                            }
                                            echo '
                                            <tr class="odd">
                                            <td>'.$result['id'].'</td>
                                            <td class=" text-center" tabindex="0">
                                                <img src="../'.$result['Logo'].'"
                                                    width="30px" alt="">
                                            </td>
                                            <td>'.$result['coinname'].'</td>
                                            <td>'.$result['Symbol'].'</td>
                                            <td class="td-decs">'.$result['Description'].'</td>
                                            <td>'.$result['Launchdate'].'</td>
                                            <td>'.$result['Marketcap'].'</td>
                                            <td>'.$result['NetworkChain'].'</td>
                                            <td>'.$result['Website'].'</td>
                                            <td>'.$result['Telegram'].'</td>
                                            <td>'.$result['Twitter'].'</td>
                                            <td>'.$result['created_at'].'</td>
                                            <td>'.$result['created_by'].'</td>
                                            <td>'.$result['votes'].'</td>
                                            <td>'.$ispromote.'</td>
                                            <td>
                                                <!-- Example single danger button -->
                                                <div class="btn-group">
                                                    <button type="button" class="btn btn-light dropdown-toggle"
                                                        data-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        Action
                                                    </button>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="'.$_SERVER['PHP_SELF']."?promoted=".$result['id'].'">promote</a>
                                                        <a class="dropdown-item" href="'.$_SERVER['PHP_SELF']."?unpromote=".$result['id'].'">Un promote</a>
                                                        
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="text-center" ><a href="updatecoin.php?id='.$result['id'].'" class="btn btn-success">Update Coin</a></td>
                                            <td class="text-center" ><a href="'.$_SERVER['PHP_SELF']."?delete=".$result['id'].'" class="btn btn-danger">Delete Coin</a></td>
                                        </tr>
                                            ';
                                        }
                                    }
                                    ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->


            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</div>
<?php include 'footer.php'; ?>